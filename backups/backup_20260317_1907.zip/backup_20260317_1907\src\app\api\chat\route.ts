import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { GoogleGenAI } from '@google/genai';

// Initialize Supabase (using Service Role for history logging if needed, or Anon for client-side matching)
// We'll use service role to ensure history can be written and vectors matched even if strict RLS is applied.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.NEXT_PUBLIC_GEMINI_API_KEY });

export async function POST(request: Request) {
  try {
    const { message, engineerId } = await request.json();

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // 1. Generate Embedding for the user's message
    const embeddingResponse = await ai.models.embedContent({
      model: 'gemini-embedding-001',
      contents: [message],
      // @ts-ignore
      outputDimensionality: 768,
    });

    const embedding = embeddingResponse.embeddings?.[0]?.values;
    if (!embedding) {
      throw new Error('Could not generate embedding for the message');
    }

    // 2. Query Supabase for relevant context using match_knowledge_chunks RPC
    console.log('Querying Supabase for matching chunks with message:', message);
    const { data: matchedChunks, error: matchError } = await supabase.rpc('match_knowledge_chunks', {
      query_embedding: embedding,
      match_threshold: 0.1, // Permissive for technical terms
      match_count: 15,       // More context for complex manuals
    });

    if (matchError) {
      console.error('Vector search error:', matchError);
    }

    if (matchedChunks && matchedChunks.length > 0) {
      console.log(`Vector search results: Found ${matchedChunks.length} matching chunks.`);
    }
    
    // 3. Construct the prompt with context
    const contextText = (matchedChunks && matchedChunks.length > 0)
      ? matchedChunks.map((chunk: any) => `[RECURSO: ${chunk.document_id}]:\n${chunk.content}`).join('\n---\n')
      : 'ADVERTENCIA: NO hay manuales exactos. Usa lógica técnica de NCR, Diebold y GRG.';

    const systemPrompt = `
      ERES EL EXPERTO TÉCNICO DE CAMPO PARA CAJEROS (NCR, DIEBOLD, GRG).
      TU MISIÓN ES DAR SOLUCIONES PRECISAS BASADAS EN LOS MANUALES DISPONIBLES.
      
      BASE DE CONOCIMIENTOS (ALTO SECRETO - MÁXIMA PRIORIDAD):
      ${contextText}
      
      REGLAS DE OPERACIÓN:
      1. SI LA INFORMACIÓN ESTÁ EN LA BASE DE CONOCIMIENTOS: Úsala obligatoriamente. Cita el ID del recurso si es relevante.
      2. PROTOCOLO MULTIMODAL: Tus respuestas deben ser visuales cuando sea posible (ej. "Ubica el sensor S1 cerca del motor de transporte").
      3. TONO: Militar, técnico, preciso. Sin rodeos.
      4. IDIOMA: ESPAÑOL.
      5. FORMATO: Pasos numerados [1..N] y uso de Markdown para resaltar piezas o errores.
    `;

    const result = await ai.models.generateContent({
      model: 'gemini-2.5-flash-lite',
      contents: [
        {
          role: 'user',
          parts: [
            { text: systemPrompt },
            { text: `CONSULTA DEL INGENIERO: ${message}` }
          ]
        }
      ]
    });

    const aiResponse = result.text;

    // 5. Log to query_history (Success or error shouldn't block the UI)
    try {
      await supabase.from('query_history').insert({
        engineer_id: engineerId || null,
        query_text: message,
        response_text: aiResponse
      });
    } catch (e) {
      console.error('Error logging query history:', e);
    }

    return NextResponse.json({ response: aiResponse });

  } catch (error: any) {
    console.error('Chat error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
