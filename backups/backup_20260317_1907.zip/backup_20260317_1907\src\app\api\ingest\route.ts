import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { GoogleGenAI } from '@google/genai';

// Initialize Supabase with Service Role Key for Admin operations
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!; // VERY IMPORTANT: Use service role key to insert chunks
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.NEXT_PUBLIC_GEMINI_API_KEY });

// Chunking function: splits text into roughly 1000-character overlapping chunks
function chunkText(text: string, chunkSize = 1000, overlap = 200): string[] {
  const chunks: string[] = [];
  let i = 0;
  while (i < text.length) {
    chunks.push(text.slice(i, i + chunkSize));
    i += chunkSize - overlap;
  }
  return chunks;
}

export async function POST(request: Request) {
  try {
    const { documentId, bucket, path, fileType, title } = await request.json();

    if (!documentId || !bucket || !path) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // 1. Download the file from Supabase Storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from(bucket)
      .download(path);

    if (downloadError || !fileData) {
      throw new Error(`Failed to download file: ${downloadError?.message}`);
    }

    const buffer = Buffer.from(await fileData.arrayBuffer());
    let extractedText = '';

    // 2. Extract text based on file type
    console.log(`Extracting text for ${fileType}...`);
    if (fileType === 'pdf' || fileType === 'image' || fileType === 'video') {
      // Use Gemini for all complex media types (PDF, Image, Video)
      const mimeType = fileType === 'pdf' ? 'application/pdf' : 
                       fileType === 'image' ? 'image/jpeg' : 'video/mp4';

      const prompt = `Analiza este documento técnico de cajeros automáticos (marcas NCR, Diebold, GRG).
      ESTRICTAMENTE EXTRAE Y GENERA UN TEXTO TÉCNICO ESTRUCTURADO QUE INCLUYA:
      1. CÓDIGOS DE ERROR: Identifica cada código y su significado exacto.
      2. PROCEDIMIENTOS DE REPARACIÓN: Paso a paso detallado para solucionar las fallas.
      3. COMPONENTES Y DIAGRAMAS: Descripción de sensores, motores, casetes y correas.
      4. SI ES IMAGEN O VIDEO: Describe visualmente qué se observa (ej. "Engranaje roto en el alimentador", "Led rojo parpadeando en la placa controladora").
      
      FORMATO DE SALIDA: Texto limpio, técnico y directo para un ingeniero de campo.`;

      const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash-lite',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  data: buffer.toString('base64'),
                  mimeType
                }
              },
              { text: prompt }
            ]
          }
        ]
      });
      
      extractedText = result.text || '';
      console.log(`Successfully extracted ${extractedText.length} characters using Gemini Multimodal.`);
    } else {
        // Fallback or simple text handling
        extractedText = buffer.toString('utf-8');
    }

    if (!extractedText.trim()) {
      return NextResponse.json({ error: 'No text extracted from file' }, { status: 400 });
    }

    // Update the main document with the extracted text (optional, but good for full-text search fallback)
    await supabase.from('knowledge_documents').update({ content_text: extractedText }).eq('id', documentId);

    // 3. Chunk the text
    const chunks = chunkText(extractedText);
    console.log(`Generated ${chunks.length} chunks.`);

    // 4. Generate Embeddings and Insert
    for (const chunk of chunks) {
      if (chunk.trim().length < 10) continue; // Skip empty chunks

      const embeddingResponse = await ai.models.embedContent({
        model: 'gemini-embedding-001',
        contents: [chunk], // Kept 'chunk' as 'message' is undefined in this context
        // @ts-ignore
        outputDimensionality: 768,
      });

      const embedding = embeddingResponse.embeddings?.[0]?.values;
      if (!embedding) {
          console.warn('Failed to generate embedding for chunk, skipping.');
          continue;
      }

      // Insert into PgVector table
      const { error: insertError } = await supabase
        .from('knowledge_chunks')
        .insert({
          document_id: documentId,
          content: chunk,
          embedding: embedding, // Supabase pgvector accepts JS arrays directly
        });
        
      if (insertError) {
          console.error('Error inserting chunk:', insertError);
      }
    }

    console.log('Ingestion process completed successfully.');
    return NextResponse.json({ success: true, chunksProcessed: chunks.length });
  } catch (error: any) {
    console.error('Ingestion error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
