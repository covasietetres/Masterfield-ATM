'use client';

import { useState, useEffect, useRef } from 'react';
import { Loader2, Send, Zap, RotateCcw, MessageSquare, Terminal as TerminalIcon, History, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function TechnicalAssistant() {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; content: string }[]>([]);
  const [textInput, setTextInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasContext, setHasContext] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isProcessing]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!textInput.trim() || isProcessing) return;

    const userMessage = textInput.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setTextInput('');
    setIsProcessing(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage })
      });

      if (!res.ok) {
        throw new Error('Error al conectar con el servidor de diagnóstico.');
      }

      const data = await res.json();
      setHasContext(data.response.includes('[RECURSO:'));
      setMessages(prev => [...prev, { role: 'ai', content: data.response }]);
    } catch (error: any) {
      setMessages(prev => [...prev, { role: 'ai', content: `⚠️ ERROR TÉCNICO: ${error.message}` }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[750px] bg-slate-950/80 backdrop-blur-2xl border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl relative">
      
      {/* Header Premium */}
      <div className="px-8 py-6 border-b border-white/5 flex items-center justify-between bg-slate-900/60">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <TerminalIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight uppercase">Terminal de Ingeniería</h2>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Base de Datos: ACTIVA</span>
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => setMessages([])}
          className="p-3 bg-slate-800/50 text-slate-400 rounded-xl hover:text-white hover:bg-slate-700 transition-all border border-white/5"
          title="Reiniciar Terminal"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>

      {/* Main Chat Area */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/40 via-transparent to-transparent"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-40">
            <div className="w-20 h-20 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
              <MessageSquare className="w-10 h-10 text-slate-500" />
            </div>
            <div>
              <p className="text-lg font-bold text-white uppercase tracking-wider">Centro de Soporte Especializado</p>
              <p className="text-sm text-slate-400 max-w-xs mx-auto mt-2">
                Consulta códigos de error, diagramas y procedimientos técnicos de NCR, Diebold y GRG.
              </p>
            </div>
          </div>
        )}

        <AnimatePresence mode="popLayout">
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} gap-4`}
            >
              {msg.role === 'ai' && (
                <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center shrink-0 mt-1">
                  <Zap className="w-4 h-4 text-indigo-400" />
                </div>
              )}
              
              <div className={`p-5 rounded-2xl max-w-[85%] shadow-xl ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-sm' 
                  : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-sm'
              }`}>
                {msg.role === 'ai' && (
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                      <History className="w-3 h-3" /> Diagnóstico del Sistema
                    </p>
                    {hasContext && (
                      <span className="flex items-center gap-1 text-[8px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        <Database className="w-2 h-2" /> MANUAL
                      </span>
                    )}
                  </div>
                )}
                <div className="text-sm leading-relaxed whitespace-pre-wrap font-medium">
                  {msg.content}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isProcessing && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4">
            <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center animate-spin">
              <Loader2 className="w-4 h-4 text-slate-600" />
            </div>
            <div className="bg-slate-800/20 border border-slate-700/30 p-4 rounded-2xl rounded-tl-sm">
              <span className="text-xs text-slate-500 font-bold uppercase tracking-widest italic animate-pulse">Consultando manuales técnicos...</span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input de Comandos */}
      <div className="p-8 bg-slate-900/80 border-t border-white/5">
        <form onSubmit={handleSendMessage} className="relative flex items-center gap-4">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            disabled={isProcessing}
            autoFocus
            placeholder="Introduce síntoma, código de falla o componente..."
            className="flex-1 bg-slate-950/50 border border-slate-800 text-slate-200 text-sm py-5 px-6 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500/50 transition-all placeholder:text-slate-600 shadow-inner"
          />
          <button
            type="submit"
            disabled={!textInput.trim() || isProcessing}
            className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:from-slate-800 disabled:to-slate-800 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-900/20 transition-all active:scale-95 group"
          >
            {isProcessing ? <Loader2 className="w-7 h-7 animate-spin" /> : <Send className="w-7 h-7 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />}
          </button>
        </form>
        <div className="mt-4 flex items-center justify-between px-2">
          <p className="text-[9px] text-slate-600 font-bold uppercase tracking-[0.2em]">Capa de Inteligencia: GEMINI 2.5 FLASH LITE</p>
          <div className="flex gap-2">
             <div className="w-1 h-1 rounded-full bg-emerald-500/50" />
             <div className="w-1 h-1 rounded-full bg-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          </div>
        </div>
      </div>
    </div>
  );
}
